import React from "react";

function BrandPage() {
  return <div>sai</div>;
}

export default BrandPage;

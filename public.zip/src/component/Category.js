import React from 'react'

const Category = () => {
  return (
   <>
   <h1>
    Category
   </h1>
   <div className='container-fluid mx-2'>
    <div className='row mt-5 mx-2'>
        <div className='col-md-3'>
            <button className='btn btn-warning w-100'></button>
        </div>
    </div>
   </div>
   </>
  )
}

export default Category

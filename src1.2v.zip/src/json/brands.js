const brands = [
  {
    id: "1",
    categoriesId: "1",
    name: "HP",
    Image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/HP_logo_2012.svg/180px-HP_logo_2012.svg.png",
  },
  {
    id: "2",
    categoriesId: "1",
    name: "Dell",
    Image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Dell_logo_2016.svg/225px-Dell_logo_2016.svg.png",
  },
  {
    id: "3",
    categoriesId: "2",
    name: "Nokia",
  },
  {
    id: "4",
    categoriesId: "2",
    name: "Samsung",
  },
];
export default brands;

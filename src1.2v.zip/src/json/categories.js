const categories = [
  {
    id: "1",
    name: "Laptop",
  },
  {
    id: "2",
    name: "Mobile",
  },
];
export default categories;

const products = [
  {
    id: "1",
    name: "HP",
    price: "100",
    rating: "4",
    description:
      "HP NoteBook is a Windows 10 laptop with a 15.60-inch display that has a resolution of 1366x768 pixels. It is powered by a Core i5 processor and it comes with 8GB of RAM. The HP NoteBook packs 256GB of SSD storage. Graphics are powered by Intel HD Graphics 620.",
    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/HP_logo_2012.svg/180px-HP_logo_2012.svg.png",
  },
  {
    id: "2",
    name: "DELL",

    image:
      "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Dell_logo_2016.svg/225px-Dell_logo_2016.svg.png",
  },
];
export default products;

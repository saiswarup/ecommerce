import React from "react";
import Filter from "./Filter";

const Products = () => {
  return (
    <div>
      <div className="container my-4 py-4">
        <div className="row"></div>
        <div>{<Filter> </Filter>}</div>
      </div>
    </div>
  );
};
export default Products;

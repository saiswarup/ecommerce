import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom/cjs/react-router-dom.min";
import { Link } from "react-router-dom";
import products from "../json/data";
import categories from "../json/categories";
import brands from "../json/brands";

function Filter() {
  const [category, setCategories] = useState([]);
  const [brand, setBrands] = useState([]);

  useEffect(() => {
    setCategories(category);
  }, []);

  const handleCategories = (id) => {
    const dt = brands.filter((x) => x.categoriesId === id);
    setBrands(dt);
  };

  return (
    <div className="row">
      <div class="col-3">
        <label for="cars">Catagogies:</label>
        <select
          id="ddlCategories"
          className="form-control"
          onChange={(e) => handleCategories(e.target.value)}
        >
          <option value="0">Select Categories:</option>
          {categories && categories !== undefined
            ? categories.map((ctr, index) => {
                return (
                  <option key={index} value={ctr.id}>
                    {ctr.name}
                  </option>
                );
              })
            : "No Categories"}
        </select>
        <br />
      </div>
      <div class="col-9">
        <div className="row">
          <div class="col-3">
            {brand && brand !== undefined
              ? brand.map((ctr, index) => {
                  return (
                    <>
                      <div class="container text-center">
                        <div class="row g-2">
                          <div class="col-6">
                            <div class="row g-2 ">
                              <img
                                src={ctr.Image}
                                className="rounded-circle shadow-4-strong"
                                width="30"
                                height="50"
                                alt={ctr.Image}
                              />
                              <Link to={`/products/${ctr.id}`}>
                                <h5>{ctr.name}</h5>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })
              : "No Image"}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Filter;

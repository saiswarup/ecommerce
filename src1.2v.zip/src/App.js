import "./App.css";
import Home from "./component/Home";
import { Switch, Route } from "react-router-dom";
import Product from "./component/Product";
import React, { useState, useEffect } from "react";
import ProductPage from "./component/ProductPage";

function App() {
  return (
    <>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/products/:productId" component={ProductPage} />
      </Switch>
    </>
  );
}

export default App;
